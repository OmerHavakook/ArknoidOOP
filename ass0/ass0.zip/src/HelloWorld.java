/**
 * @author Omer Havakook <darhavakook@gmail.com>
 * @version 1.6
 * @since 2010-03-31
 */
public class HelloWorld {
    /**
    *
    * @param args
    *            input from the user
    */
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            System.out.println("Hi");
        }
    }
}
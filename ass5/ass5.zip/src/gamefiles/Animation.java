package gamefiles;

import biuoop.DrawSurface;

/**
 * A Animation interface.
 *
 */
public interface Animation {
    /**
     * draws one frame.
     *
     * @param d
     *            the drawsurface to drawon.
     */
    void doOneFrame(DrawSurface d);

    /**
     * detrmine if animation should stop.
     *
     * @return true if should stop false otherwise.
     */
    boolean shouldStop();
}

import java.util.List;
import java.util.Map;

/**
 * BaseExpression Interface.
 */
public interface Expression {
    /**
     * evaluate the expression with a given assigment.
     *
     * @param assignment
     *            the assignment of vars.
     * @return the value of evaluate expression.
     * @throws Exception
     *             if assigment does not contain all vars.
     */
    double evaluate(Map<String, Double> assignment) throws Exception;

    /**
     * evaluate this expression with no vars.
     *
     * @return the evaluate expression.
     * @throws Exception
     *             if expression includes var.
     */
    double evaluate() throws Exception;

    /**
     * get list of all vars in the expression.
     *
     * @return l a list with all vars in this.
     */
    List<String> getVariables();

    /**
     * Div to String.
     *
     * @return the converted Expression as a String.
     */
    String toString();

    /**
     * assign a value to a variable.
     *
     * @param var
     *            the variable we assign to.
     * @param expression
     *            the expression to assign in var.
     * @return the new expression after assignment.
     */
    Expression assign(String var, Expression expression);

    /**
     * return the diffrential of this expression given a var to diffrentiate
     * accord.
     *
     * @param var
     *            the var we differintiate according to.
     * @return the diff "var" of this expression.
     */
    Expression differentiate(String var);

    /**
     * return a simplification of this expression.
     *
     * @return this simplified expression.
     */
    Expression simplify();

}

import biuoop.DrawSurface;

import java.awt.Color;

/**
 * A Ball class.
 *
 * @author Omer Havakook <darhavakook@gmail.com>
 */
public class Ball {

    private Point center;
    private int radius;
    private Color color;
    private Velocity vel;
    private Boundary bound;

    /**
     * Construct a ball given point center int radius and color.
     *
     * @param center
     *            the center point of the ball.
     * @param r
     *            the radius of the ball.
     * @param color
     *            the color of the ball.
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.radius = r;
        this.color = color;
    }

    /**
     * Construct a ball given x coordinate y coordinate int radius and color.
     *
     * @param x
     *            the x coordinate of the center point of the ball.
     * @param y
     *            the y coordinate of the center point of the ball.
     * @param r
     *            the radius of the ball.
     * @param color
     *            the color of the ball.
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.radius = r;
        this.color = color;
    }

    /**
     * @return the x coordinate of the center.
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * @return the y coordinate of the center.
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * @return the radius of the ball.
     */
    public int getSize() {
        return this.radius;
    }

    /**
     * @return the color of the ball.
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * draw ball by given draw face.
     *
     * @param surface
     *            DrawFace to draw on.
     */
    // draw the ball on the given DrawSurface
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle(this.getX(), this.getY(), this.radius);
    }

    /**
     * set the ball boundary by given Boundary param.
     *
     * @param b
     *            Boundary to set.
     */
    public void setBoundary(Boundary b) {
        this.bound = b;
    }

    /**
     * set the ball boundary by given 4 coordinates.
     *
     * @param u
     *            the up boundary.
     * @param d
     *            the down boundary.
     * @param l
     *            the left boundary.
     * @param r
     *            the right boundary.
     */
    public void setBoundary(int u, int d, int l, int r) {
        this.bound = new Boundary(u, d, l, r);
    }

    /**
     * @return the boundary of the ball.
     */
    public Boundary getBoundary() {
        return this.bound;
    }

    /**
     * set the ball velocity by given Velocity param.
     *
     * @param v
     *            velocity to set.
     */
    public void setVelocity(Velocity v) {
        this.vel = v;
    }

    /**
     * set the ball velocity by given 2 vectors.
     *
     * @param dx
     *            the x vector of velocity.
     * @param dy
     *            the y vector of velocity.
     */
    public void setVelocity(double dx, double dy) {
        this.vel = new Velocity(dx, dy);
    }

    /**
     * @return the velocity of the ball.
     */
    public Velocity getVelocity() {
        return this.vel;
    }

    /**
     * change the dy direction of the ball.
     */
    public void changeHorizontal() {
        this.setVelocity(this.vel.getDX(), -this.vel.getDY());
    }

    /**
     * change the dx direction of the ball.
     */
    public void changeVertical() {
        this.setVelocity(-this.vel.getDX(), this.vel.getDY());
    }

    /**
     * change the location of the ball by checking the boundaries by one step.
     */
    public void moveOneStep() {
        this.center = this.getVelocity().applyToPoint(this.center);
        if (this.center.getX() + this.radius >= this.bound.getRightBound()) {
            this.changeVertical();
            this.center = new Point(this.bound.getRightBound() - this.radius, this.getY());
        }
        if (this.center.getX() - this.radius <= this.bound.getLeftBound()) {
            this.changeVertical();
            this.center = new Point(this.bound.getLeftBound() + this.radius, this.getY());
        }
        if (this.center.getY() - this.radius <= this.bound.getUpBound()) {
            this.changeHorizontal();
            this.center = new Point(this.getX(), this.bound.getUpBound() + this.radius);
        }
        if (this.center.getY() + this.radius >= this.bound.getDownBound()) {
            this.changeHorizontal();
            this.center = new Point(this.getX(), this.bound.getDownBound() - this.radius);
        }

    }

}

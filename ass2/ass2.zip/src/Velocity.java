import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * A Velocity class.
 *
 * @author Omer Havakook <darhavakook@gmail.com>
 */
public class Velocity {

    private double dx;
    private double dy;

    /**
     * Construct a Velocity given dx coordinate dy coordinate.
     *
     * @param dx
     *            the x coordinate of the vector.
     * @param dy
     *            the y coordinate of the vector.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * create a Velocity given angle and speed.
     *
     * @param angle
     *            the angle of the velocity vector.
     * @param speed
     *            the size of of the velocity vector.
     * @return the new velocity.
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dx = speed * Math.cos(Math.toRadians(angle));
        double dy = speed * Math.sin(Math.toRadians(angle));
        return new Velocity(dx, dy);
    }

    /**
     * @return the dx of the velocity.
     */
    public double getDX() {
        return this.dx;
    }

    /**
     * @return the dy of the velocity.
     */
    public double getDY() {
        return this.dy;
    }

    /**
     * Take a point with position (x,y) and return a new point with position
     * (x+dx, y+dy).
     *
     * @param p
     *            point of the location.
     * @return a new point with position (x+dx, y+dy).
     */
    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }

    /**
     *
     * @param args
     *            input from the user
     */
    public static void main(String[] args) {

        GUI gui = new GUI("title", 400, 400);
        biuoop.Sleeper sleeper = new Sleeper();
        Ball ball = new Ball(120, 30, 30, java.awt.Color.BLACK);
        ball.setVelocity(2, 2);
        while (true) {
            ball.moveOneStep();
            DrawSurface d = gui.getDrawSurface();
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50); // wait for 50 milliseconds.
        }
    }
}
